`timescale 1ns / 1ps
//==============================================================================
// alu.v  -  Arithmetic Logic Unit (Stage 3 - EX)
//
// Pure combinational logic.
//   op = 0 : ADD   result = a + b           Z, C (carry out)
//   op = 1 : SUB   result = a - b           Z, C (borrow: 1 when a < b)
//   op = 2 : AND   result = a & b           Z
//   op = 3 : OR    result = a | b           Z
//   op = 4 : XOR   result = a ^ b           Z
//   op = 5 : SHL   result = a << 1          Z, C = old bit 7
//   op = 6 : SHR   result = a >> 1          Z, C = old bit 0
//   op = 7 : PASS  result = b               (used by LDI)
//
// Outputs:
//   z     : 1 when result == 0
//   c     : carry / borrow / shifted-out bit
//   c_upd : 1 when this operation is allowed to change the C flag
//           (AND, OR, XOR only change Z, so c_upd = 0 for them)
//==============================================================================
module alu (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [2:0] op,
    output reg  [7:0] result,
    output wire       z,
    output reg        c,
    output reg        c_upd
);

    always @(*) begin
        // Default values first: guarantees no latch is inferred.
        result = 8'h00;
        c      = 1'b0;
        c_upd  = 1'b0;

        case (op)
            3'd0: begin                                   // ADD
                {c, result} = {1'b0, a} + {1'b0, b};
                c_upd       = 1'b1;
            end
            3'd1: begin                                   // SUB
                {c, result} = {1'b0, a} - {1'b0, b};      // bit 8 = borrow
                c_upd       = 1'b1;
            end
            3'd2: result = a & b;                         // AND
            3'd3: result = a | b;                         // OR
            3'd4: result = a ^ b;                         // XOR
            3'd5: begin                                   // SHL
                result = {a[6:0], 1'b0};
                c      = a[7];
                c_upd  = 1'b1;
            end
            3'd6: begin                                   // SHR
                result = {1'b0, a[7:1]};
                c      = a[0];
                c_upd  = 1'b1;
            end
            default: result = b;                          // 7: pass B (LDI)
        endcase
    end

    assign z = (result == 8'h00);

endmodule
