`timescale 1ns / 1ps
//==============================================================================
// dmem.v  -  Data memory (RAM), 256 x 8 bits, Stage 4 - MEM
//
//   * Asynchronous read  (LD): rdata follows addr in the same cycle.
//   * Synchronous write  (ST): mem[addr] <= wdata at the rising clock edge
//     when we = 1.
//   * Initialised to 0 (works in simulation and as FPGA initial value).
//   * Vivado maps this to distributed (LUT) RAM.
//==============================================================================
module dmem (
    input  wire       clk,
    input  wire       we,
    input  wire [7:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata
);

    reg [7:0] mem [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1)
            mem[i] = 8'h00;
    end

    always @(posedge clk) begin
        if (we)
            mem[addr] <= wdata;
    end

    assign rdata = mem[addr];

endmodule
