`timescale 1ns / 1ps
//==============================================================================
// imem.v  -  Instruction memory (ROM), 256 x 16 bits, Stage 1 - IF
//
// The test program is written directly in this file (no external .hex file),
// so Vivado cannot lose it. Reading is asynchronous: the instruction appears
// in the same cycle as the address.
//
// To change the program, edit the case items below. Encoding:
//   R  : opcode(4) rd(3) rs1(3) rs2(3) 000
//   R1 : opcode(4) rd(3) rs1(3) 000000
//   I  : opcode(4) rd(3) 0      imm8
//   J  : opcode(4) 0000         addr8
// Opcodes (hex): 0 NOP, 1 ADD, 2 SUB, 3 AND, 4 OR, 5 XOR, 6 SHL, 7 SHR,
//                8 LDI, 9 ADDI, A LD, B ST, C JMP, D BZ, E BNZ, F HLT
//
// Test program (expected final state: R1..R7 = 00 0F 01 20 00 66 00,
//               mem[0x20] = 0x0F, Z = 1, C = 1)
//==============================================================================
module imem (
    input  wire [7:0]  addr,
    output reg  [15:0] instr
);

    always @(*) begin
        case (addr)
            // ---- loop: R2 = 5+4+3+2+1, R1 counts 5 -> 0 ------------------
            8'd0  : instr = 16'h8205;   // LDI  R1, 0x05
            8'd1  : instr = 16'h8400;   // LDI  R2, 0x00
            8'd2  : instr = 16'h1488;   // ADD  R2, R2, R1      <- loop start
            8'd3  : instr = 16'h92FF;   // ADDI R1, 0xFF        (R1 = R1 - 1)
            8'd4  : instr = 16'hE002;   // BNZ  0x02            (taken 4 times)
            // ---- store / load / load-use stall ----------------------------
            8'd5  : instr = 16'h8820;   // LDI  R4, 0x20
            8'd6  : instr = 16'hB500;   // ST   R2, [R4]        mem[0x20] = 0x0F
            8'd7  : instr = 16'hAB00;   // LD   R5, [R4]        R5 = 0x0F
            8'd8  : instr = 16'h9AF1;   // ADDI R5, 0xF1        load-use stall; R5 = 0x00, Z=1, C=1
            // ---- taken branch with two wrong-path instructions ------------
            8'd9  : instr = 16'hD00C;   // BZ   0x0C            (taken, Z = 1)
            8'd10 : instr = 16'h8EFF;   // LDI  R7, 0xFF        wrong path: must be flushed
            8'd11 : instr = 16'h8CAA;   // LDI  R6, 0xAA        wrong path: must be flushed
            // ---- ALU test with forwarding at distance 1, 3 ---------------
            8'd12 : instr = 16'h8C66;   // LDI  R6, 0x66        <- BZ target
            8'd13 : instr = 16'h3790;   // AND  R3, R6, R2      R3 = 0x06
            8'd14 : instr = 16'h66C0;   // SHL  R3, R3          R3 = 0x0C
            8'd15 : instr = 16'h46F0;   // OR   R3, R3, R6      R3 = 0x6E (R6 bypass, distance 3)
            8'd16 : instr = 16'h56D0;   // XOR  R3, R3, R2      R3 = 0x61
            8'd17 : instr = 16'h26F0;   // SUB  R3, R3, R6      R3 = 0xFB, C = 1 (borrow)
            8'd18 : instr = 16'h76C0;   // SHR  R3, R3          R3 = 0x7D, C = 1
            8'd19 : instr = 16'h0000;   // NOP
            8'd20 : instr = 16'h9683;   // ADDI R3, 0x83        R3 = 0x00, Z = 1, C = 1
            8'd21 : instr = 16'h8601;   // LDI  R3, 0x01        R3 = 1 (flags unchanged)
            8'd22 : instr = 16'hC019;   // JMP  0x19
            8'd23 : instr = 16'h8E55;   // LDI  R7, 0x55        wrong path: must be flushed
            8'd24 : instr = 16'h8677;   // LDI  R3, 0x77        wrong path: must be flushed
            8'd25 : instr = 16'hF000;   // HLT
            default: instr = 16'h0000;  // NOP everywhere else
        endcase
    end

endmodule
