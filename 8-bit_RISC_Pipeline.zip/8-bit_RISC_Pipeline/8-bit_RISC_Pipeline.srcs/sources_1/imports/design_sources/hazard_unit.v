`timescale 1ns / 1ps
//==============================================================================
// hazard_unit.v  -  Forwarding and load-use stall detection (combinational)
//
// 1) Forwarding for the instruction in EX (operands A and B separately):
//      sel = 1 : take the ALU result of the instruction in MEM (EX/MEM)
//      sel = 2 : take the result of the instruction in WB      (MEM/WB)
//      sel = 0 : use the value read from the register file in ID
//    EX/MEM has priority (it holds the newer value). A load in MEM cannot be
//    forwarded from EX/MEM (its data is not ready yet), see 2).
//
// 2) Load-use stall: a load is in EX and the instruction in ID reads the
//    register that the load will write -> stall one cycle (hold PC and
//    IF/ID, insert a bubble into ID/EX). One cycle later the load is in WB
//    and normal forwarding supplies the value.
//==============================================================================
module hazard_unit (
    // instruction in EX: which registers it reads
    input  wire [2:0] idex_ra,
    input  wire [2:0] idex_rb,
    input  wire       idex_uses_a,
    input  wire       idex_uses_b,
    // instruction in MEM
    input  wire       exmem_reg_we,      // already 0 for bubbles
    input  wire       exmem_mem_to_reg,  // 1 = it is a load
    input  wire [2:0] exmem_rd,
    // instruction in WB
    input  wire       memwb_reg_we,      // already 0 for bubbles
    input  wire [2:0] memwb_rd,
    // load-use detection: load in EX versus instruction in ID
    input  wire       idex_valid,
    input  wire       idex_mem_to_reg,
    input  wire [2:0] idex_rd,
    input  wire       ifid_valid,
    input  wire [2:0] id_ra,
    input  wire [2:0] id_rb,
    input  wire       id_uses_a,
    input  wire       id_uses_b,
    // outputs
    output wire [1:0] fwd_a_sel,
    output wire [1:0] fwd_b_sel,
    output wire       stall
);

    // ---- forwarding, operand A ------------------------------------------
    wire a_from_mem = idex_uses_a & exmem_reg_we & ~exmem_mem_to_reg
                      & (exmem_rd == idex_ra);
    wire a_from_wb  = idex_uses_a & memwb_reg_we & (memwb_rd == idex_ra);
    assign fwd_a_sel = a_from_mem ? 2'd1 :
                       a_from_wb  ? 2'd2 : 2'd0;

    // ---- forwarding, operand B ------------------------------------------
    wire b_from_mem = idex_uses_b & exmem_reg_we & ~exmem_mem_to_reg
                      & (exmem_rd == idex_rb);
    wire b_from_wb  = idex_uses_b & memwb_reg_we & (memwb_rd == idex_rb);
    assign fwd_b_sel = b_from_mem ? 2'd1 :
                       b_from_wb  ? 2'd2 : 2'd0;

    // ---- load-use stall ---------------------------------------------------
    assign stall = idex_valid & idex_mem_to_reg & ifid_valid &
                   ( (id_uses_a & (id_ra == idex_rd)) |
                     (id_uses_b & (id_rb == idex_rd)) );

endmodule
