`timescale 1ns / 1ps
//==============================================================================
// regfile.v  -  Register file R0..R7 (8 bits each)
//
//   * 2 asynchronous read ports (A and B)   -> used in stage ID
//   * 1 synchronous write port              -> used in stage WB
//   * Write-through bypass: if the register being written in this cycle is
//     the same one being read, the NEW value (wdata) is returned at once.
//     This covers the case where producer and consumer are 3 instructions
//     apart (producer in WB, consumer in ID).
//   * R0 is an ordinary register (it is not hard-wired to zero).
//   * Synchronous reset clears all registers to 0.
//==============================================================================
module regfile (
    input  wire       clk,
    input  wire       rst,
    input  wire       we,          // write enable (from WB stage)
    input  wire [2:0] waddr,       // register to write
    input  wire [7:0] wdata,       // value to write
    input  wire [2:0] raddr_a,     // read port A address
    input  wire [2:0] raddr_b,     // read port B address
    output wire [7:0] rdata_a,
    output wire [7:0] rdata_b
);

    reg [7:0] regs [0:7];
    integer i;

    always @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 8; i = i + 1)
                regs[i] <= 8'h00;
        end else if (we) begin
            regs[waddr] <= wdata;
        end
    end

    // Read with bypass
    assign rdata_a = (we && (waddr == raddr_a)) ? wdata : regs[raddr_a];
    assign rdata_b = (we && (waddr == raddr_b)) ? wdata : regs[raddr_b];

endmodule
