`timescale 1ns / 1ps
//==============================================================================
// risc8_5stage_core.v  -  Top level of the 8-bit RISC processor, 5-stage pipeline
//
//   IF  -> IF/ID  -> ID  -> ID/EX  -> EX  -> EX/MEM  -> MEM  -> MEM/WB  -> WB
//
// Inputs : clk, rst
// Outputs: halted     1 after HLT has completed (pipeline frozen)
//          pc_out     current fetch address
//          flags_out  {C, Z}   (bit 1 = carry/borrow, bit 0 = zero)
//          instr_done 1 in every cycle in which an instruction completes (WB)
//
// Every pipeline register carries a "valid" bit. valid = 0 is a bubble: all
// of its write enables are 0, so it cannot change registers, memory or flags.
//
// Next-state priority for PC / IF/ID / ID/EX:
//      flush (taken branch)  >  halt  >  load-use stall  >  normal
//==============================================================================
module risc8_5stage_core (
    input  wire       clk,
    input  wire       rst,
    output wire       halted,
    output wire [7:0] pc_out,
    output wire [1:0] flags_out,
    output wire       instr_done
);

    //==========================================================================
    // Stage 1 - IF : program counter and instruction memory
    //==========================================================================
    reg  [7:0]  pc;
    wire [7:0]  pc_plus1 = pc + 8'd1;
    wire [15:0] if_instr;

    imem u_imem (.addr(pc), .instr(if_instr));

    // IF/ID pipeline register
    reg [15:0] ifid_instr;
    reg        ifid_valid;

    //==========================================================================
    // Stage 2 - ID : decode, control signals, register read
    //==========================================================================
    wire [3:0] id_opcode = ifid_instr[15:12];
    wire [2:0] id_rd     = ifid_instr[11:9];
    wire [2:0] id_rs1    = ifid_instr[8:6];
    wire [2:0] id_rs2    = ifid_instr[5:3];
    wire [7:0] id_imm8   = ifid_instr[7:0];

    wire [2:0] c_alu_op;
    wire       c_alu_src_imm, c_ra_is_rd, c_rb_is_rd, c_uses_a, c_uses_b;
    wire       c_reg_we, c_mem_to_reg, c_mem_we, c_flag_we;
    wire       c_jump, c_br_z, c_br_nz, c_halt;

    control_unit u_ctrl (
        .opcode      (id_opcode),
        .alu_op      (c_alu_op),
        .alu_src_imm (c_alu_src_imm),
        .ra_is_rd    (c_ra_is_rd),
        .rb_is_rd    (c_rb_is_rd),
        .uses_a      (c_uses_a),
        .uses_b      (c_uses_b),
        .reg_we      (c_reg_we),
        .mem_to_reg  (c_mem_to_reg),
        .mem_we      (c_mem_we),
        .flag_we     (c_flag_we),
        .jump        (c_jump),
        .br_z        (c_br_z),
        .br_nz       (c_br_nz),
        .halt        (c_halt)
    );

    // Which registers are read: ADDI reads rd on port A, ST reads rd on port B
    wire [2:0] id_ra_num = c_ra_is_rd ? id_rd : id_rs1;
    wire [2:0] id_rb_num = c_rb_is_rd ? id_rd : id_rs2;

    wire [7:0] id_rdata_a, id_rdata_b;

    // Write-back signals (defined in stage 5, used here)
    wire       wb_we;
    wire [7:0] wb_data;
    wire [2:0] wb_rd;

    regfile u_regfile (
        .clk     (clk),
        .rst     (rst),
        .we      (wb_we),
        .waddr   (wb_rd),
        .wdata   (wb_data),
        .raddr_a (id_ra_num),
        .raddr_b (id_rb_num),
        .rdata_a (id_rdata_a),
        .rdata_b (id_rdata_b)
    );

    // ID/EX pipeline register (valid + 14 control bits + rd + 2 reg numbers
    //                          + 2 reg values + imm8)
    reg        idex_valid;
    reg [2:0]  idex_alu_op;
    reg        idex_alu_src_imm;
    reg        idex_flag_we;
    reg        idex_jump, idex_br_z, idex_br_nz, idex_halt;
    reg        idex_mem_we, idex_mem_to_reg;
    reg        idex_reg_we;
    reg        idex_uses_a, idex_uses_b;
    reg [2:0]  idex_rd, idex_ra, idex_rb;
    reg [7:0]  idex_a, idex_b, idex_imm8;

    //==========================================================================
    // Stage 3 - EX : forwarding, ALU, flags, branch decision
    //==========================================================================
    wire [1:0] fwd_a_sel, fwd_b_sel;
    wire       stall;

    // EX/MEM pipeline register
    reg        exmem_valid;
    reg        exmem_reg_we, exmem_mem_to_reg, exmem_mem_we, exmem_halt;
    reg [2:0]  exmem_rd;
    reg [7:0]  exmem_result, exmem_addr, exmem_wdata;

    // MEM/WB pipeline register
    reg        memwb_valid;
    reg        memwb_reg_we, memwb_halt;
    reg [2:0]  memwb_rd;
    reg [7:0]  memwb_result;

    hazard_unit u_hazard (
        .idex_ra          (idex_ra),
        .idex_rb          (idex_rb),
        .idex_uses_a      (idex_uses_a),
        .idex_uses_b      (idex_uses_b),
        .exmem_reg_we     (exmem_valid & exmem_reg_we),
        .exmem_mem_to_reg (exmem_mem_to_reg),
        .exmem_rd         (exmem_rd),
        .memwb_reg_we     (memwb_valid & memwb_reg_we),
        .memwb_rd         (memwb_rd),
        .idex_valid       (idex_valid),
        .idex_mem_to_reg  (idex_mem_to_reg),
        .idex_rd          (idex_rd),
        .ifid_valid       (ifid_valid),
        .id_ra            (id_ra_num),
        .id_rb            (id_rb_num),
        .id_uses_a        (c_uses_a),
        .id_uses_b        (c_uses_b),
        .fwd_a_sel        (fwd_a_sel),
        .fwd_b_sel        (fwd_b_sel),
        .stall            (stall)
    );

    // Forwarding multiplexers: 0 = from ID, 1 = EX/MEM, 2 = MEM/WB
    wire [7:0] ex_a = (fwd_a_sel == 2'd1) ? exmem_result :
                      (fwd_a_sel == 2'd2) ? wb_data      : idex_a;
    wire [7:0] ex_b = (fwd_b_sel == 2'd1) ? exmem_result :
                      (fwd_b_sel == 2'd2) ? wb_data      : idex_b;

    // ALU input B: register value or immediate
    wire [7:0] alu_b = idex_alu_src_imm ? idex_imm8 : ex_b;

    wire [7:0] alu_result;
    wire       alu_z, alu_c, alu_c_upd;

    alu u_alu (
        .a      (ex_a),
        .b      (alu_b),
        .op     (idex_alu_op),
        .result (alu_result),
        .z      (alu_z),
        .c      (alu_c),
        .c_upd  (alu_c_upd)
    );

    // Flags
    reg z_flag, c_flag;

    // Branch logic: decided in EX, using flags that are already up to date
    wire take_branch = idex_valid &
                       ( idex_jump |
                         (idex_br_z  &  z_flag) |
                         (idex_br_nz & ~z_flag) );

    // Halt control
    reg  halting;      // set once HLT has been seen in EX: fetch stays stopped
    reg  halted_r;     // set when HLT has completed in WB: everything frozen
    wire halt_stop = halting | (idex_valid & idex_halt);

    //==========================================================================
    // Stage 4 - MEM : data memory
    //==========================================================================
    wire [7:0] mem_rdata;
    wire       dmem_we = exmem_valid & exmem_mem_we & ~halted_r;

    dmem u_dmem (
        .clk   (clk),
        .we    (dmem_we),
        .addr  (exmem_addr),
        .wdata (exmem_wdata),
        .rdata (mem_rdata)
    );

    wire [7:0] mem_result = exmem_mem_to_reg ? mem_rdata : exmem_result;

    //==========================================================================
    // Stage 5 - WB : register write
    //==========================================================================
    assign wb_we   = memwb_valid & memwb_reg_we & ~halted_r;
    assign wb_data = memwb_result;
    assign wb_rd   = memwb_rd;

    //==========================================================================
    // Bubble condition for ID/EX
    //==========================================================================
    wire id_bubble = take_branch | halt_stop | stall | ~ifid_valid;

    //==========================================================================
    // The single clocked block: updates every register
    //==========================================================================
    always @(posedge clk) begin
        if (rst) begin
            pc               <= 8'h00;
            ifid_instr       <= 16'h0000;
            ifid_valid       <= 1'b0;

            idex_valid       <= 1'b0;
            idex_alu_op      <= 3'd0;
            idex_alu_src_imm <= 1'b0;
            idex_flag_we     <= 1'b0;
            idex_jump        <= 1'b0;
            idex_br_z        <= 1'b0;
            idex_br_nz       <= 1'b0;
            idex_halt        <= 1'b0;
            idex_mem_we      <= 1'b0;
            idex_mem_to_reg  <= 1'b0;
            idex_reg_we      <= 1'b0;
            idex_uses_a      <= 1'b0;
            idex_uses_b      <= 1'b0;
            idex_rd          <= 3'd0;
            idex_ra          <= 3'd0;
            idex_rb          <= 3'd0;
            idex_a           <= 8'h00;
            idex_b           <= 8'h00;
            idex_imm8        <= 8'h00;

            exmem_valid      <= 1'b0;
            exmem_reg_we     <= 1'b0;
            exmem_mem_to_reg <= 1'b0;
            exmem_mem_we     <= 1'b0;
            exmem_halt       <= 1'b0;
            exmem_rd         <= 3'd0;
            exmem_result     <= 8'h00;
            exmem_addr       <= 8'h00;
            exmem_wdata      <= 8'h00;

            memwb_valid      <= 1'b0;
            memwb_reg_we     <= 1'b0;
            memwb_halt       <= 1'b0;
            memwb_rd         <= 3'd0;
            memwb_result     <= 8'h00;

            z_flag           <= 1'b0;
            c_flag           <= 1'b0;
            halting          <= 1'b0;
            halted_r         <= 1'b0;
        end
        else if (!halted_r) begin   // once halted, every register holds its value

            //------------------------------------------------------------------
            // HLT reaches WB -> freeze from the next cycle on
            //------------------------------------------------------------------
            if (memwb_valid & memwb_halt)
                halted_r <= 1'b1;

            //------------------------------------------------------------------
            // MEM -> MEM/WB
            //------------------------------------------------------------------
            memwb_valid  <= exmem_valid;
            memwb_reg_we <= exmem_valid & exmem_reg_we;
            memwb_halt   <= exmem_valid & exmem_halt;
            memwb_rd     <= exmem_rd;
            memwb_result <= mem_result;

            //------------------------------------------------------------------
            // EX -> EX/MEM
            //------------------------------------------------------------------
            exmem_valid      <= idex_valid;
            exmem_reg_we     <= idex_valid & idex_reg_we;
            exmem_mem_to_reg <= idex_valid & idex_mem_to_reg;
            exmem_mem_we     <= idex_valid & idex_mem_we;
            exmem_halt       <= idex_valid & idex_halt;
            exmem_rd         <= idex_rd;
            exmem_result     <= alu_result;
            exmem_addr       <= ex_a;        // LD / ST address = port A
            exmem_wdata      <= ex_b;        // ST data         = port B

            // Flags: only a valid instruction that is allowed to change them
            if (idex_valid & idex_flag_we) begin
                z_flag <= alu_z;
                if (alu_c_upd)
                    c_flag <= alu_c;
            end

            // HLT seen in EX: stop fetching from now on
            if (idex_valid & idex_halt)
                halting <= 1'b1;

            //------------------------------------------------------------------
            // ID -> ID/EX  (bubble: all enables 0)
            //------------------------------------------------------------------
            if (id_bubble) begin
                idex_valid       <= 1'b0;
                idex_alu_op      <= 3'd0;
                idex_alu_src_imm <= 1'b0;
                idex_flag_we     <= 1'b0;
                idex_jump        <= 1'b0;
                idex_br_z        <= 1'b0;
                idex_br_nz       <= 1'b0;
                idex_halt        <= 1'b0;
                idex_mem_we      <= 1'b0;
                idex_mem_to_reg  <= 1'b0;
                idex_reg_we      <= 1'b0;
                idex_uses_a      <= 1'b0;
                idex_uses_b      <= 1'b0;
                idex_rd          <= 3'd0;
                idex_ra          <= 3'd0;
                idex_rb          <= 3'd0;
                idex_a           <= 8'h00;
                idex_b           <= 8'h00;
                idex_imm8        <= 8'h00;
            end else begin
                idex_valid       <= 1'b1;
                idex_alu_op      <= c_alu_op;
                idex_alu_src_imm <= c_alu_src_imm;
                idex_flag_we     <= c_flag_we;
                idex_jump        <= c_jump;
                idex_br_z        <= c_br_z;
                idex_br_nz       <= c_br_nz;
                idex_halt        <= c_halt;
                idex_mem_we      <= c_mem_we;
                idex_mem_to_reg  <= c_mem_to_reg;
                idex_reg_we      <= c_reg_we;
                idex_uses_a      <= c_uses_a;
                idex_uses_b      <= c_uses_b;
                idex_rd          <= id_rd;
                idex_ra          <= id_ra_num;
                idex_rb          <= id_rb_num;
                idex_a           <= id_rdata_a;
                idex_b           <= id_rdata_b;
                idex_imm8        <= id_imm8;     // also the branch target
            end

            //------------------------------------------------------------------
            // IF -> IF/ID and PC     priority: flush > halt > stall > normal
            //------------------------------------------------------------------
            if (take_branch) begin                 // flush: go to target
                pc          <= idex_imm8;
                ifid_instr  <= 16'h0000;
                ifid_valid  <= 1'b0;
            end else if (halt_stop) begin          // halt: stop fetching
                pc          <= pc;
                ifid_instr  <= 16'h0000;
                ifid_valid  <= 1'b0;
            end else if (stall) begin              // load-use: hold PC and IF/ID
                pc          <= pc;
                ifid_instr  <= ifid_instr;
                ifid_valid  <= ifid_valid;
            end else begin                         // normal
                pc          <= pc_plus1;
                ifid_instr  <= if_instr;
                ifid_valid  <= 1'b1;
            end
        end
    end

    //==========================================================================
    // Observation outputs
    //==========================================================================
    assign halted     = halted_r;
    assign pc_out     = pc;
    assign flags_out  = {c_flag, z_flag};
    assign instr_done = memwb_valid & ~halted_r;

endmodule
