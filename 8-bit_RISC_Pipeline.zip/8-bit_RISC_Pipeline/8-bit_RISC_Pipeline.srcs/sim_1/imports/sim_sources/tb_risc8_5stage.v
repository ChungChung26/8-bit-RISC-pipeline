`timescale 1ns / 1ps
//==============================================================================
// tb_risc8_5stage.v  -  Self-checking testbench
//
//   * generates a 100 MHz clock (10 ns) and holds reset for 2 cycles
//   * prints one line per clock cycle (pipeline trace)
//   * waits for the 'halted' output
//   * compares R1..R7, memory[0x20] and the flags with the expected values
//   * prints PASS / FAIL and the performance numbers, then stops
//==============================================================================
module tb_risc8_5stage;

    reg        clk;
    reg        rst;
    wire       halted;
    wire [7:0] pc_out;
    wire [1:0] flags_out;
    wire       instr_done;

    risc8_5stage_core dut (
        .clk        (clk),
        .rst        (rst),
        .halted     (halted),
        .pc_out     (pc_out),
        .flags_out  (flags_out),
        .instr_done (instr_done)
    );

    //--------------------------------------------------------------------------
    // Clock and reset
    //--------------------------------------------------------------------------
    initial clk = 1'b0;
    always #5 clk = ~clk;                 // period 10 ns = 100 MHz

    initial begin
        rst = 1'b1;
        repeat (2) @(posedge clk);        // reset held for 2 clock edges
        #1 rst = 1'b0;
    end

    //--------------------------------------------------------------------------
    // Statistics and cycle trace
    //--------------------------------------------------------------------------
    integer cycles, instrs, stalls, taken, fwds;

    initial begin
        cycles = 0;
        instrs = 0;
        stalls = 0;
        taken  = 0;
        fwds   = 0;
    end

    always @(posedge clk) begin
        if (!rst && !halted) begin
            cycles = cycles + 1;
            if (instr_done)           instrs = instrs + 1;
            if (dut.stall)            stalls = stalls + 1;
            if (dut.take_branch)      taken  = taken  + 1;
            if (dut.idex_valid && dut.fwd_a_sel != 2'd0) fwds = fwds + 1;
            if (dut.idex_valid && dut.fwd_b_sel != 2'd0) fwds = fwds + 1;

            $display("cyc %2d | pc=%02h | IF/ID %04h v=%b | EX v=%b | Z=%b C=%b | stall=%b branch=%b fwdA=%0d fwdB=%0d | done=%b",
                     cycles, dut.pc, dut.ifid_instr, dut.ifid_valid, dut.idex_valid,
                     flags_out[0], flags_out[1], dut.stall, dut.take_branch,
                     dut.fwd_a_sel, dut.fwd_b_sel, instr_done);
        end
    end

    //--------------------------------------------------------------------------
    // Self-checking
    //--------------------------------------------------------------------------
    integer errors, checks;

    task check8;
        input [8*12-1:0] name;
        input [7:0]      got;
        input [7:0]      expected;
        begin
            checks = checks + 1;
            if (got === expected)
                $display("  PASS  %0s = 0x%02h", name, got);
            else begin
                $display("  FAIL  %0s = 0x%02h, expected 0x%02h", name, got, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        errors = 0;
        checks = 0;

        wait (halted === 1'b1);           // program finished
        repeat (2) @(posedge clk);        // let the outputs settle

        $display("");
        $display("---------------- Results ----------------");
        check8("R1",          dut.u_regfile.regs[1], 8'h00);
        check8("R2",          dut.u_regfile.regs[2], 8'h0F);
        check8("R3",          dut.u_regfile.regs[3], 8'h01);
        check8("R4",          dut.u_regfile.regs[4], 8'h20);
        check8("R5",          dut.u_regfile.regs[5], 8'h00);
        check8("R6",          dut.u_regfile.regs[6], 8'h66);
        check8("R7",          dut.u_regfile.regs[7], 8'h00);
        check8("MEM[0x20]",   dut.u_dmem.mem[8'h20], 8'h0F);
        check8("Flags {C,Z}", {6'b000000, flags_out},  8'h03);

        $display("");
        $display("Cycles = %0d, instructions = %0d, CPI = %0.2f",
                 cycles, instrs, (cycles * 1.0) / instrs);
        $display("Load-use stalls = %0d, taken branches = %0d, forwarded operands = %0d",
                 stalls, taken, fwds);
        $display("");

        if (errors == 0)
            $display("*** ALL TESTS PASSED *** (%0d of %0d checks)", checks, checks);
        else
            $display("*** %0d TEST(S) FAILED *** (%0d of %0d checks)", errors, checks - errors, checks);

        $finish;
    end

    // Safety net: stop if the processor never halts
    initial begin
        #5000;
        $display("*** FAIL: timeout, the processor never halted ***");
        $finish;
    end

endmodule
