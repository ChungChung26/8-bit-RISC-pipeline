# =============================================================================
# risc8.xdc - Vivado constraints for risc8_5stage_core
#
# 1) The clock constraint below is all that is needed for synthesis,
#    implementation and timing analysis.
# 2) To generate a bitstream, enable the pin assignments below (they are
#    written for the Digilent Basys-3 board, part xc7a35tcpg236-1). For another
#    board, replace the PACKAGE_PIN values with the pins from its manual.
# =============================================================================

# ---- Clock: 100 MHz (period 10 ns) -----------------------------------------
create_clock -period 10.000 -name sys_clk [get_ports clk]

# ---- Pin assignments for Basys-3 (remove the leading '#' to enable) --------
# set_property -dict { PACKAGE_PIN W5  IOSTANDARD LVCMOS33 } [get_ports clk]
# set_property -dict { PACKAGE_PIN U18 IOSTANDARD LVCMOS33 } [get_ports rst]      ;# button BTNC

# set_property -dict { PACKAGE_PIN U16 IOSTANDARD LVCMOS33 } [get_ports {pc_out[0]}]
# set_property -dict { PACKAGE_PIN E19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[1]}]
# set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[2]}]
# set_property -dict { PACKAGE_PIN V19 IOSTANDARD LVCMOS33 } [get_ports {pc_out[3]}]
# set_property -dict { PACKAGE_PIN W18 IOSTANDARD LVCMOS33 } [get_ports {pc_out[4]}]
# set_property -dict { PACKAGE_PIN U15 IOSTANDARD LVCMOS33 } [get_ports {pc_out[5]}]
# set_property -dict { PACKAGE_PIN U14 IOSTANDARD LVCMOS33 } [get_ports {pc_out[6]}]
# set_property -dict { PACKAGE_PIN V14 IOSTANDARD LVCMOS33 } [get_ports {pc_out[7]}]
# set_property -dict { PACKAGE_PIN V13 IOSTANDARD LVCMOS33 } [get_ports {flags_out[0]}]   ;# Z
# set_property -dict { PACKAGE_PIN V3  IOSTANDARD LVCMOS33 } [get_ports {flags_out[1]}]   ;# C
# set_property -dict { PACKAGE_PIN W3  IOSTANDARD LVCMOS33 } [get_ports instr_done]
# set_property -dict { PACKAGE_PIN U3  IOSTANDARD LVCMOS33 } [get_ports halted]

# set_property CFGBVS VCCO [current_design]
# set_property CONFIG_VOLTAGE 3.3 [current_design]
